from .core import deep_flatten, flatten_limited, flatten_list

__version__ = "0.1.2"